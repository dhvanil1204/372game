/* 
This file wraps the animation logic. But is not needed if animation is not desired.

How to use:
           function Sprite(url, pos, size, speed, frames, dir, once)
           url = location to sprite map.
           pos = starting position on the image on the sprite map.
           size = the size[x,y] px length of the image taken from the sprite map.
           speed = aprxoimation on frames / second, calculated independant from actual frame for effiecency.
           frames = the frames you want to animte on the sprite map, example [0, 1, 2, 3]. then goes in reverse
           dir = the direction the way you select the image on the sprite map.
           once = how many times to animate, true/false default = false.

           example of loading your specific sprite map: resources.load(['img/sprites.png']);
           
           Sprite.prototype is the class that handles the logic for animation if animation is desired.
           should be fairly easy to understand whats happening as long as you understand the sprite function.

*/



/*global resources*/

(function () {
   
    function Sprite(url, pos, size, speed, frames, dir, once) {
        this.pos = pos;
        this.size = size;
        this.speed = typeof speed === 'number' ? speed : 0;
        this.frames = frames;
        this.index = 0;
        this.url = url;
        this.dir = dir || 'horizontal';
        this.once = once;
    }

    Sprite.prototype = {
        update: function (dt) {
            this.index += this.speed * dt;
        },

        render: function (ctx) {
            var frame,
                x = this.pos[0],
                y = this.pos[1],
            
                max,
                index;

            if (this.speed > 0) {
                max = this.frames.length;
                index = Math.floor(this.index);
                frame = this.frames[index % max];

                if (this.once && index >= max) {
                    this.done = true;
                    return;
                }
            } else {
                frame = 0;
            }

            if (this.dir === 'vertical') {
                y += frame * this.size[1];
            } else {
                x += frame * this.size[0];
            }
            
            ctx.drawImage(resources.get(this.url),
                          x, y,
                          this.size[0], this.size[1],
                          0, 0,
                          this.size[0], this.size[1]);
        }
    };
    
    window.Sprite = Sprite;
    
}());