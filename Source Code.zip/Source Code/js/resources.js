/*global img_load, isReady*/
(function () {
    "use strict";
    var resourceCache = {},
        loading = [],
        readyCallbacks = [];

    function load(urlOrArr) {                                                               // Load an image url or an array of image urls
        if (urlOrArr instanceof Array) {
            urlOrArr.forEach(function (url) {
                img_load(url);
            });
        } else {
            img_load(urlOrArr);
        }
    }

    function img_load(url) {
        if (resourceCache[url]) {
            return resourceCache[url];
        } else {
            var img = new Image();                                                          // Create a new img variable
            img.onload = function () {
                resourceCache[url] = img;                                                   // Store the new image object

                if (isReady()) {                                                            // Check to see if all images are loaded
                    readyCallbacks.forEach(function (func) { func(); });                    // Calls all the callbacks in the array
                }
            };
            resourceCache[url] = false;
            img.src = url;                                                                  // Start the image loading
        }
    }

    function get(url) {
        return resourceCache[url];
    }

    function isReady() {
        var ready = true,
            k;
        for (k in resourceCache) {                                                          // For each image inside of resourceCache, resourceCache.hasOwnProperty(k) will always return true
            if (resourceCache.hasOwnProperty(k) && !resourceCache[k]) {
                ready = false;
            }
        }
        return ready;
    }

    function onReady(func) {
        readyCallbacks.push(func);
    }

    window.resources = { load: load,
                         get: get,
                         onReady: onReady,
                         isReady: isReady
                       };
}());