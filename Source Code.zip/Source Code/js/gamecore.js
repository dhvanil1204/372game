/*global update, 

render, resources, Sprite, updateEntities, handleInput, checkCollisions, input, renderEntity, checkPlayerBounds, reset, gameOver*/
/*global renderEntities*/
var width = 1024;
var height = 480;
var canvas = document.createElement("canvas");
var ctx = canvas.getContext("2d");
var gameTime = 0;
var terrainPattern;
var playerSpeed = 200;
var lightCycleTail = 50;
var lastTime;
var continuousMovement = 10;
var moveState = moveState;
var isGameOver = false;
var isPreGame = false;
var tailLength;
var lastKeyPress;
var bulletSpeed = 800;
var lastFire = Date.now();
var bulletCount = bulletCount;
var status;
var xs,ys;
canvas.width = width;
canvas.height = height;
document.body.appendChild(canvas);
ctx.font = "30px arial";
var players = [];
//var socket = io();
var socket = io();


socket.on('ho',function(data){

players.push({  pos: [0, 0],
    sprite: new Sprite('img/bike.png', [0, 0], [99, 42], 6, [0, 1])

});

});


/*players[1] = {  pos: [100, 100],
    sprite: new Sprite('img/bike.png', [0, 0], [99, 42], 6, [0, 1]) };
*/var player = players[0];
var requestAnimFrame = (function () {
    "use strict";
    return window.requestAnimationFrame       ||
           window.webkitRequestAnimationFrame ||
           window.mozRequestAnimationFrame    ||
           window.oRequestAnimationFrame      ||
           window.msRequestAnimationFrame     ||
        function (callback) {
            window.setTimeout(callback, 1000 / 60);
        };
}());

function main() {
   

    "use strict";
   

 socket.emit('yo',{


});
    var timeInMs = Date.now(), date = (timeInMs - lastTime) / 1000.0;
    update(date);
    render();
   
    lastTime = timeInMs;
    requestAnimFrame(main);
}

function init() {
    "use strict";
    terrainPattern = ctx.createPattern(resources.get('img/test1.png'), 'repeat');
    document.getElementById('play-again').addEventListener('click', function () {
        reset();
    });
    
    document.getElementById('play').addEventListener('click', function () {
        reset();
        isPreGame = false;
    });
    
    document.getElementById('main-menu').addEventListener('click', function () {
        reset();
        preGame();
    });
    
    document.getElementById('options').addEventListener('click', function () {
        optionsMenu();
    });

    reset();
    lastTime = Date.now();
    preGame();
    main();
}

resources.load(['img/bike.png', 'img/test1.png', 'img/sprites.png', 'img/lightcycles.png']);
resources.onReady(init);


var lightCycleTail = [];
var bullets = [];


function update(dt) {
    "use strict";
   
    gameTime += dt;
    handleInput(dt);
    updateEntities(dt);
    
    lightCycleTail.push({
        //pos:
        //sprite: new Sprite('img/sprites.png', [0, 78], [80, 39], 6, [0, 1, 2, 3, 2, 1])
    });
    

    checkCollisions();

}

function checkCollisions() {
    "use strict";
    checkPlayerBounds();
}


function render() {
    "use strict";

    ctx.fillStyle = terrainPattern;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (!isGameOver && !isPreGame) {
          renderEntities(players);
    }
 
    renderEntities(bullets);
}

function renderEntity(entity) {
    "use strict";
    ctx.save();
    ctx.translate(entity.pos[0], entity.pos[1]);
    
    entity.sprite.render(ctx);
    ctx.restore();
}

function renderEntities(list) {
    "use strict";
    var i;
    for (i = 0; i < list.length; i += 1) {
        renderEntity(list[i]);
    }
}

function handleInput(dt) {
    "use strict";
    if (!isPreGame) {

        if ((input.isDown('DOWN') || input.isDown('s')) && (status !== 1) && lastKeyPress !== 'UP') {
            lastKeyPress = 'DOWN';
            player.pos[1] += playerSpeed * dt;
            moveState = 1;
        } else if ((input.isDown('UP') || input.isDown('w')) && (status !== 2) && lastKeyPress !== 'DOWN') {
            lastKeyPress = 'UP';
            player.pos[1] -= playerSpeed * dt;
            moveState = 2;
        } else if ((input.isDown('LEFT') || input.isDown('a')) && (status !== 3) && lastKeyPress !== 'RIGHT') {
            lastKeyPress = 'LEFT';
            player.pos[0] -= playerSpeed * dt;
            moveState = 3;
        } else if ((input.isDown('RIGHT') || input.isDown('d')) && (status !== 4) && lastKeyPress !== 'LEFT') {
            lastKeyPress = 'RIGHT';
            player.pos[0] += playerSpeed * dt;
            moveState = 4;
        } else if (input.isDown('SPACE') && !isGameOver && Date.now() - lastFire > 100 && moveState === 4) {
            if (bulletCount > 0) {
                var x = player.pos[0] + player.sprite.size[0] / 2;
                var y = player.pos[1] + player.sprite.size[1] / 2;
                bullets.push({ pos: [x, y],
                               dir: 'forward',
                               sprite: new Sprite('img/sprites.png', [0, 39], [18, 8]) });
                lastFire = Date.now();
                bulletCount -= 1;
            }
            if (bulletCount < 0) {
                bulletCount = 0;
            }
        } else if (input.isDown('SPACE') && !isGameOver && Date.now() - lastFire > 100 && moveState === 3) {
            if (bulletCount > 0) {
                x = player.pos[0] + player.sprite.size[0] / 2;
                y = player.pos[1] + player.sprite.size[1] / 2;
                bullets.push({ pos: [x, y],
                               dir: 'backward',
                               sprite: new Sprite('img/sprites.png', [0, 39], [18, 8]) });
                lastFire = Date.now();
                bulletCount -= 1;
            }
            if (bulletCount < 0) {
                bulletCount = 0;
            }
        } else if (input.isDown('SPACE') && !isGameOver && Date.now() - lastFire > 100 && moveState === 2) {
            if (bulletCount > 0) {
                x = player.pos[0] + player.sprite.size[0] / 2;
                y = player.pos[1] + player.sprite.size[1] / 2;
                bullets.push({ pos: [x, y],
                               dir: 'up',
                               sprite: new Sprite('img/sprites.png', [0, 39], [18, 8]) });
                lastFire = Date.now();
                bulletCount -= 1;
            }
            if (bulletCount < 0) {
                bulletCount = 0;
            }
        } else if (input.isDown('SPACE') && !isGameOver && Date.now() - lastFire > 100 && moveState === 1) {
            if (bulletCount > 0) {
                x = player.pos[0] + player.sprite.size[0] / 2;
                y = player.pos[1] + player.sprite.size[1] / 2;
                bullets.push({ pos: [x, y],
                               dir: 'down',
                               sprite: new Sprite('img/sprites.png', [0, 39], [18, 8]) });
                lastFire = Date.now();
                bulletCount -= 1;
            }
            if (bulletCount < 0) {
                bulletCount = 0;
            }
        } else if (input.isDown('SPACE') && !isGameOver && Date.now() - lastFire > 100 && moveState === 5) {
            if (bulletCount > 0) {
                x = player.pos[0] + player.sprite.size[0] / 2;
                y = player.pos[1] + player.sprite.size[1] / 2;
                bullets.push({ pos: [x, y],
                               dir: 'forward',
                               sprite: new Sprite('img/sprites.png', [0, 39], [18, 8]) });
                lastFire = Date.now();
                bulletCount -= 1;
            }
            if (bulletCount < 0) {
                bulletCount = 0;
            }
        }

        if (moveState === 1) {
            player.pos[1] += playerSpeed * dt;

        } else if (moveState === 2) {
            player.pos[1] -= playerSpeed * dt;

        } else if (moveState === 3) {
            player.pos[0] -= playerSpeed * dt;

        } else if (moveState === 4) {
            player.pos[0] += playerSpeed * dt;

        } else if (moveState === 5) {
            player.pos[0] = playerSpeed * dt;

        }
    }

}

function checkPlayerBounds() {
    "use strict";
    if (player.pos[0] < 0) {
        player.pos[0] = 0;
        gameOver();
    } else if (player.pos[0] > canvas.width - player.sprite.size[0]) {
        player.pos[0] = canvas.width - player.sprite.size[0];
        gameOver();
    }

    if (player.pos[1] < 0) {
        player.pos[1] = 0;
        gameOver();
    } else if (player.pos[1] > canvas.height - player.sprite.size[1]) {
        player.pos[1] = canvas.height - player.sprite.size[1];
        gameOver();
    }
}

function updateEntities(dt) {
    "use strict";
    for(var x =0;x<players.length;x++){
    players[x].sprite.update(dt);
    }
    for (var i = 0; i < bullets.length; i += 1) {
        var bullet = bullets[i];

        switch(bullet.dir) {
        case 'up': bullet.pos[1] -= bulletSpeed * dt; break;
        case 'down': bullet.pos[1] += bulletSpeed * dt; break;
        case 'backward': bullet.pos[0] -= bulletSpeed * dt; break;
        default:
            bullet.pos[0] += bulletSpeed * dt;
        }

        // Remove the bullet if it goes offscreen
        if(bullet.pos[1] < 0 || bullet.pos[1] > canvas.height ||
           bullet.pos[0] > canvas.width) {
            bullets.splice(i, 1);
            i--;
        }
    }
}

function gameOver() {
    "use strict";
    document.getElementById('game-over').style.display = 'block';
    document.getElementById('game-over-overlay').style.display = 'block';
    isGameOver = true;
}

function preGame() {
    "use strict";
    document.getElementById('game-start').style.display = 'block';
    document.getElementById('game-start-overlay').style.display = 'block';
    isPreGame = true;
}

function optionsMenu() {
    "use strict";
    //document.getElementById('game-start').style.display = 'block';
    //document.getElementById('game-start-overlay').style.display = 'block';
    //isPreGame = true;
}

function reset() {
    "use strict";
    document.getElementById('game-over').style.display = 'none';
    document.getElementById('game-over-overlay').style.display = 'none';
    document.getElementById('game-start').style.display = 'none';
    document.getElementById('game-start-overlay').style.display = 'none';
    isGameOver = false;
    gameTime = 0;
    moveState = 5;
    lastKeyPress = false;
   // player.pos = [xs, ys];
    bulletCount = 3;
}